﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Threading.Tasks;

namespace Common_Service_Project
{
    /// <summary>
    /// Summary description for Handler1
    /// </summary>
    /// 
    public class Handler1 : HttpTaskAsyncHandler
    {
        //   http://localhost:54829/handler1.ashx?A=1&B=2&cmd=plus

        public override async Task ProcessRequestAsync(HttpContext context)
        {
            string result = "";
            if (context.Request.QueryString["cmd"] !=null)
            {

                switch (context.Request.QueryString["cmd"])
                {
                    case "colorAverage":
                        result = await Task<string>.Run(() =>  ColorAverage(ref context));
                        break;
                }
              
            }
            context.Response.Write(result);
            
        }

        public override bool IsReusable
        {
            get
            {
                return false;
            }
        }

        private string ColorAverage(ref HttpContext context)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            int r = 0, g = 0, b = 0;
            if (context.Request.QueryString["A"] != null)
            {
                TextAndColor atac = ser.Deserialize<TextAndColor>(context.Request.QueryString["A"]);
                TextAndColor btac = ser.Deserialize<TextAndColor>(context.Request.QueryString["B"]);
                r = atac.R;
                r += btac.R;
                g = atac.G;
                g += btac.G;
                b = atac.B;
                b += btac.B;
            }
            TextAndColor res = new TextAndColor(r / 2, g / 2, b / 2, "");
            return ser.Serialize(res);
        }

    }

}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Common_ASP_Project
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected Button[,] arrButtons;
        protected const byte BUTTONSIZE = 50;
        protected void Page_Load(object sender, System.EventArgs e)
        {

            arrButtons = new Button[4, 4];
            short i;
            for (i = 0; i < 4; i++)
            {
                for (int j = 0; j < arrButtons.GetLength(1); ++j)
                {
                    if (i == 3 && j == 3) goto end;
                    Button tmp = new Button();
                    tmp.Attributes.Add("id", (i * 4 + j + 1).ToString());
                    tmp.Attributes.Add("AutoPostback", "false");
                    tmp.Attributes.Add("onclick", "javascript:myClick(this.id);");
                    int topMargin = i * BUTTONSIZE + 20;
                    int leftMargin = j * BUTTONSIZE + 20;
                    tmp.Attributes.Add("style", $"top: {topMargin}; left: {leftMargin}; position: absolute");
                    arrButtons[i, j] = tmp;
                    PlaceHolder1.Controls.Add(tmp);

                }
            }
        end:;
            if (!IsPostBack)
            {
                for (i = 0; i < arrButtons.GetLength(0); i++)
                {
                    for (int j = 0; j < arrButtons.GetLength(1); ++j)
                    {
                        if (i == 3 && j == 3) goto end1;
                        arrButtons[i, j].Text = (i * 4 + j + 1).ToString();
                        arrButtons[i, j].Width = 50;
                        arrButtons[i, j].Height = 50;
                        arrButtons[i, j].Font.Size = new FontUnit("X-Large");
                    }
                }
            }
        end1:;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Common_Service_Project
{
    [Serializable]
    public class TextAndColor
    {
        public int R;
        public int G;
        public int B;
        public string text;
        public TextAndColor(int r, int g, int b, string txt)
        {
            R = r; G = g; B = b; text = txt;
        }
        public TextAndColor() { R = G = B = 0; text = ""; }
    }
}